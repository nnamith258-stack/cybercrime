import React from 'react';
import { ActiveTab } from '../types/forensics';
import { Sparkles, Download } from 'lucide-react';

interface Props {
  activeTab: ActiveTab;
  onNavigateTab: (tab: ActiveTab) => void;
  onLoadDemo: () => void;
  onDownloadZip: () => void;
}

export const TopBar: React.FC<Props> = ({ activeTab, onNavigateTab, onLoadDemo, onDownloadZip }) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-6 py-3.5 flex items-center justify-between">
      {/* Zone 1: Single text element wordmark */}
      <button
        onClick={() => onNavigateTab('dashboard')}
        className="text-lg font-bold tracking-tight text-slate-100 hover:text-cyan-400 transition-colors whitespace-nowrap"
      >
        ReCoveAI
      </button>

      {/* Zone 2: 4-6 clean text navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
        <button
          onClick={() => onNavigateTab('dashboard')}
          className={`transition-colors whitespace-nowrap ${
            activeTab === 'dashboard' ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-slate-100'
          }`}
        >
          Dashboard
        </button>
        <button
          onClick={() => onNavigateTab('upload')}
          className={`transition-colors whitespace-nowrap ${
            activeTab === 'upload' ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-slate-100'
          }`}
        >
          Upload & Scan
        </button>
        <button
          onClick={() => onNavigateTab('fragments')}
          className={`transition-colors whitespace-nowrap ${
            activeTab === 'fragments' ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-slate-100'
          }`}
        >
          Fragment Explorer
        </button>
        <button
          onClick={() => onNavigateTab('recovered')}
          className={`transition-colors whitespace-nowrap ${
            activeTab === 'recovered' ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-slate-100'
          }`}
        >
          Recovered Files
        </button>
        <button
          onClick={() => onNavigateTab('graph')}
          className={`transition-colors whitespace-nowrap ${
            activeTab === 'graph' ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-slate-100'
          }`}
        >
          Evidence Graph
        </button>
        <button
          onClick={() => onNavigateTab('tools')}
          className={`transition-colors whitespace-nowrap ${
            activeTab === 'tools' ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-slate-100'
          }`}
        >
          Forensic Tools
        </button>
      </nav>

      {/* Zone 3: 1-2 primary actions */}
      <div className="flex items-center gap-2.5">
        <button
          onClick={onLoadDemo}
          className="px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5"
          title="Reload Hackathon Demo Scenario"
        >
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>Demo Data</span>
        </button>

        <button
          onClick={onDownloadZip}
          className="px-3.5 py-1.5 text-xs font-semibold text-white bg-cyan-600 rounded-lg hover:bg-cyan-500 transition-colors whitespace-nowrap flex items-center gap-1.5 shadow-sm shadow-cyan-950"
          title="Download complete project package as ZIP"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Download .ZIP</span>
        </button>
      </div>
    </header>
  );
};
