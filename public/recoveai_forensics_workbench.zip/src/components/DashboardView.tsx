import React from 'react';
import { ForensicScanResult, ReconstructedFile } from '../types/forensics';
import { formatBytes, formatHexOffset } from '../utils/forensicEngine';
import {
  Shield,
  Layers,
  FileCheck,
  AlertTriangle,
  CopyCheck,
  Cpu,
  ArrowRight,
  TrendingUp,
  Activity,
  FileText,
  Image as ImageIcon,
  Film,
  FileCode,
  Sparkles,
  Download
} from 'lucide-react';

interface Props {
  scanResult: ForensicScanResult;
  onSelectFile: (file: ReconstructedFile) => void;
  onNavigateTab: (tab: any) => void;
  onLoadDemo: () => void;
  onDownloadAllZip?: () => void;
}

export const DashboardView: React.FC<Props> = ({
  scanResult,
  onSelectFile,
  onNavigateTab,
  onLoadDemo,
  onDownloadAllZip
}) => {
  const { stats, reconstructedFiles, fragments } = scanResult;

  // File type distribution count
  const typeCounts = reconstructedFiles.reduce((acc, f) => {
    acc[f.fileType] = (acc[f.fileType] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="space-y-6">
      {/* Top Banner & Scenario Callout */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl overflow-hidden border border-cyan-500/30 bg-slate-950 shrink-0 hidden sm:flex items-center justify-center shadow-md">
            <img
              src="/src/assets/images/forensic_lab_badge_1790319307480.jpg"
              alt="ReCoveAI Seal"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
              onError={e => {
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-mono uppercase tracking-wider text-slate-400">Forensic Workspace Active</span>
              <span className="text-xs text-slate-500">·</span>
              <span className="text-xs text-cyan-400 font-mono">Read-Only Mode</span>
            </div>
            <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              Target Evidence: <span className="font-mono text-cyan-300">{scanResult.datasetName}</span>
            </h2>
            <p className="text-xs text-slate-400">
              {formatBytes(scanResult.datasetSizeBytes)} inspected across {fragments.length} logical sectors ({scanResult.sectorSize} B/sector) · Scanned at {new Date(scanResult.scanTimestamp).toLocaleTimeString()}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {onDownloadAllZip && (
            <button
              onClick={onDownloadAllZip}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 border border-slate-700 shadow-sm"
              title="Download entire forensic evidence archive as a ZIP file"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>Download Evidence (.ZIP)</span>
            </button>
          )}
          <button
            onClick={() => onNavigateTab('upload')}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition-colors flex items-center gap-2"
          >
            <span>Scan Another Image</span>
          </button>
          <button
            onClick={onLoadDemo}
            className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-2 shadow-lg shadow-cyan-950"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Reload Demo Dataset</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Total Fragments */}
        <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-medium uppercase tracking-wider">Total Fragments</span>
            <Layers className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100 font-tabular">
            {stats.totalFragments}
          </div>
          <div className="text-[10px] text-slate-500">Logical storage clusters</div>
        </div>

        {/* Identified Fragments */}
        <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-medium uppercase tracking-wider">Identified Frags</span>
            <Cpu className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400 font-tabular">
            {stats.identifiedFragments}
          </div>
          <div className="text-[10px] text-slate-500">{((stats.identifiedFragments / stats.totalFragments) * 100).toFixed(0)}% signature match</div>
        </div>

        {/* Reconstructed Files */}
        <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-medium uppercase tracking-wider">Reconstructed</span>
            <FileCheck className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-cyan-400 font-tabular">
            {stats.reconstructedFiles}
          </div>
          <div className="text-[10px] text-slate-500">{stats.fullyRecoveredFiles} complete files</div>
        </div>

        {/* Partial Files */}
        <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-medium uppercase tracking-wider">Partial Files</span>
            <Activity className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-400 font-tabular">
            {stats.partiallyRecoveredFiles}
          </div>
          <div className="text-[10px] text-slate-500">With missing sector gaps</div>
        </div>

        {/* Corrupted / Unrec */}
        <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-medium uppercase tracking-wider">Unrecoverable</span>
            <AlertTriangle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-rose-400 font-tabular">
            {stats.unrecoverableFiles + stats.corruptedFiles}
          </div>
          <div className="text-[10px] text-slate-500">Cipher / broken headers</div>
        </div>

        {/* Duplicates */}
        <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-medium uppercase tracking-wider">Duplicates</span>
            <CopyCheck className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-purple-400 font-tabular">
            {stats.duplicateFilesCount}
          </div>
          <div className="text-[10px] text-slate-500">SHA-256 deduplicated</div>
        </div>
      </div>

      {/* AI Summary Highlight Panel */}
      <div className="bg-slate-900/60 border border-cyan-900/40 rounded-2xl p-5 space-y-3 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-cyan-400" />
            <h3 className="text-xs font-semibold uppercase tracking-wider text-cyan-400">
              AI-Assisted Investigation Summary
            </h3>
          </div>
          <button
            onClick={() => onNavigateTab('report')}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1"
          >
            <span>View Full Investigation Report</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed max-w-4xl">
          {scanResult.aiForensicSummary.executiveOverview}
        </p>

        {/* Observed vs Inferred distinction */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 text-xs">
          <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1.5 mb-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              Directly Observed Physical Facts
            </span>
            <ul className="space-y-1 text-slate-400 text-[11px]">
              {scanResult.aiForensicSummary.directFacts.slice(0, 3).map((f, i) => (
                <li key={i} className="truncate">· {f}</li>
              ))}
            </ul>
          </div>

          <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] font-semibold text-purple-400 flex items-center gap-1.5 mb-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
              AI Classification & Heuristic Inferences
            </span>
            <ul className="space-y-1 text-slate-400 text-[11px]">
              {scanResult.aiForensicSummary.aiInferences.slice(0, 3).map((inf, i) => (
                <li key={i} className="truncate">· {inf}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Forensic Visual Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* File Type Distribution */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-xs font-semibold text-slate-300">File Type Breakdown</span>
            <span className="text-[10px] text-slate-500 font-mono">By Recognized Format</span>
          </div>

          <div className="space-y-2 text-xs">
            {Object.entries(typeCounts).map(([type, count]) => {
              const pct = (count / reconstructedFiles.length) * 100;
              const barColor =
                type === 'JPEG' ? 'bg-cyan-500' :
                type === 'PDF' ? 'bg-rose-500' :
                type === 'TXT' ? 'bg-emerald-500' :
                type === 'DOCX' ? 'bg-blue-500' :
                type === 'MP4' ? 'bg-purple-500' : 'bg-amber-500';

              return (
                <div key={type} className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="font-mono text-slate-300">{type}</span>
                    <span className="text-slate-400 font-mono">{count} files ({pct.toFixed(0)}%)</span>
                  </div>
                  <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden">
                    <div className={`${barColor} h-full rounded-full transition-all`} style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recovery Status Radial Breakdown */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-xs font-semibold text-slate-300">Reconstruction Health</span>
            <span className="text-[10px] text-slate-500 font-mono">Integrity Status</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800/80">
              <span className="text-[11px] text-slate-400 block">Fully Intact</span>
              <span className="text-xl font-bold font-mono text-emerald-400">{stats.fullyRecoveredFiles}</span>
              <div className="w-full bg-slate-900 h-1 rounded mt-1.5 overflow-hidden">
                <div className="bg-emerald-500 h-full" style={{ width: `${(stats.fullyRecoveredFiles / stats.reconstructedFiles) * 100}%` }} />
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800/80">
              <span className="text-[11px] text-slate-400 block">Partial Recover</span>
              <span className="text-xl font-bold font-mono text-amber-400">{stats.partiallyRecoveredFiles}</span>
              <div className="w-full bg-slate-900 h-1 rounded mt-1.5 overflow-hidden">
                <div className="bg-amber-500 h-full" style={{ width: `${(stats.partiallyRecoveredFiles / stats.reconstructedFiles) * 100}%` }} />
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800/80">
              <span className="text-[11px] text-slate-400 block">Unrecoverable</span>
              <span className="text-xl font-bold font-mono text-rose-400">{stats.unrecoverableFiles + stats.corruptedFiles}</span>
              <div className="w-full bg-slate-900 h-1 rounded mt-1.5 overflow-hidden">
                <div className="bg-rose-500 h-full" style={{ width: `${((stats.unrecoverableFiles + stats.corruptedFiles) / stats.reconstructedFiles) * 100}%` }} />
              </div>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800/80">
              <span className="text-[11px] text-slate-400 block">Deduplicated</span>
              <span className="text-xl font-bold font-mono text-purple-400">{stats.duplicateFilesCount}</span>
              <div className="w-full bg-slate-900 h-1 rounded mt-1.5 overflow-hidden">
                <div className="bg-purple-500 h-full" style={{ width: `${(stats.duplicateFilesCount / stats.reconstructedFiles) * 100}%` }} />
              </div>
            </div>
          </div>
        </div>

        {/* Quality Gauges */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-xs font-semibold text-slate-300">Confidence & Integrity</span>
            <span className="text-[10px] text-slate-500 font-mono">Weighted Mean</span>
          </div>

          <div className="space-y-4 pt-1 text-xs">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-400">Mean AI Confidence</span>
                <span className="font-mono text-purple-400 font-semibold">{stats.averageConfidence}%</span>
              </div>
              <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden">
                <div className="bg-gradient-to-r from-purple-500 to-cyan-500 h-full rounded-full" style={{ width: `${stats.averageConfidence}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-400">Mean Structural Integrity</span>
                <span className="font-mono text-emerald-400 font-semibold">{stats.averageIntegrity}%</span>
              </div>
              <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden">
                <div className="bg-gradient-to-r from-amber-500 to-emerald-500 h-full rounded-full" style={{ width: `${stats.averageIntegrity}%` }} />
              </div>
            </div>

            <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
              <span>Carving Rule: Non-Destructive</span>
              <span className="text-cyan-400 font-mono">Forensic Standard</span>
            </div>
          </div>
        </div>
      </div>

      {/* 4-Tier Causality & Modular Toolchain Callouts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Card 1: 4-Tier Graph Shortcut */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-3">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono uppercase tracking-wider text-purple-400 font-semibold">
                Causality & Risk Architecture
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800">
                4-Tier Pipeline
              </span>
            </div>
            <h3 className="text-sm font-bold text-slate-100">
              Fragments ──► Files ──► Entities ──► Risk Indicators
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Trace evidentiary lineage from raw disk sectors to assembled files, OCR extracted badge credentials, and cyber threat indicators.
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('graph')}
            className="w-full py-2 px-3 bg-purple-950/60 hover:bg-purple-900/60 text-purple-300 border border-purple-800/80 rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-1.5"
          >
            <span>Inspect 4-Tier Evidence Topology</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Card 2: Modular Forensic Toolchains Shortcut */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-3">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono uppercase tracking-wider text-cyan-400 font-semibold">
                Extensibility Layer
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                Native Fallback Active
              </span>
            </div>
            <h3 className="text-sm font-bold text-slate-100">
              TSK · PhotoRec · Foremost · OCR · OpenCV
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Optional external tool integration bridges with cross-platform instructions for Windows, Linux, and macOS.
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('tools')}
            className="w-full py-2 px-3 bg-cyan-950/60 hover:bg-cyan-900/60 text-cyan-300 border border-cyan-800/80 rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-1.5"
          >
            <span>View Toolchain Setup & OS Commands</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Recovered Artifacts Inventory Preview Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
              Reconstructed Evidence Artifacts ({reconstructedFiles.length})
            </h3>
          </div>
          <button
            onClick={() => onNavigateTab('recovered')}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1"
          >
            <span>View All in Evidence Explorer</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-950/80 text-slate-400 text-[11px] font-mono border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-4 font-medium">ARTIFACT NAME</th>
                <th className="py-2.5 px-3 font-medium">TYPE</th>
                <th className="py-2.5 px-3 font-medium">SECTOR RANGE</th>
                <th className="py-2.5 px-3 font-medium text-right">SIZE</th>
                <th className="py-2.5 px-3 font-medium text-center">RECOVERY</th>
                <th className="py-2.5 px-3 font-medium text-center">INTEGRITY</th>
                <th className="py-2.5 px-3 font-medium text-center">AI CONF</th>
                <th className="py-2.5 px-4 font-medium">STATUS</th>
                <th className="py-2.5 px-4 font-medium text-right">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
              {reconstructedFiles.map(file => (
                <tr
                  key={file.id}
                  onClick={() => onSelectFile(file)}
                  className="hover:bg-slate-850/50 transition-colors cursor-pointer group"
                >
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded bg-slate-950 text-cyan-400 border border-slate-800">
                        {file.fileType === 'JPEG' ? <ImageIcon className="w-3.5 h-3.5" /> :
                         file.fileType === 'MP4' ? <Film className="w-3.5 h-3.5" /> :
                         <FileText className="w-3.5 h-3.5" />}
                      </div>
                      <div>
                        <div className="font-semibold text-slate-100 group-hover:text-cyan-300 transition-colors">
                          {file.name}
                        </div>
                        {file.isDuplicate && (
                          <span className="text-[10px] text-amber-400">Duplicate of FILE-REC-01</span>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-3 text-slate-300">{file.fileType}</td>
                  <td className="py-3 px-3 text-slate-400">
                    {formatHexOffset(file.sourceSectorStart)} - {formatHexOffset(file.sourceSectorEnd)}
                  </td>
                  <td className="py-3 px-3 text-right text-slate-300 font-tabular">{formatBytes(file.sizeBytes)}</td>
                  <td className="py-3 px-3 text-center">
                    <span className="text-cyan-400 font-semibold">{file.recoveryPercentage}%</span>
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span className="text-emerald-400 font-semibold">{file.integrityPercentage}%</span>
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span className="text-purple-400 font-semibold">{file.aiConfidence}%</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-semibold ${
                      file.status === 'fully_recovered' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                      file.status === 'partially_recovered' ? 'bg-amber-950 text-amber-400 border border-amber-800' :
                      'bg-rose-950 text-rose-400 border border-rose-800'
                    }`}>
                      {file.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={e => {
                        e.stopPropagation();
                        onSelectFile(file);
                      }}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded text-[11px] transition-colors"
                    >
                      Inspect
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
