/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ActiveTab, ForensicScanResult, ReconstructedFile } from './types/forensics';
import { generateDemoForensicDataset } from './utils/forensicEngine';
import { downloadCompleteEvidenceZip } from './utils/filePayloadGenerator';
import { TopBar } from './components/TopBar';
import { DashboardView } from './components/DashboardView';
import { UploadScanView } from './components/UploadScanView';
import { FragmentExplorerView } from './components/FragmentExplorerView';
import { RecoveredFilesView } from './components/RecoveredFilesView';
import { EvidenceGraphView } from './components/EvidenceGraphView';
import { ForensicToolsView } from './components/ForensicToolsView';
import { AnalysisReportView } from './components/AnalysisReportView';
import { FileDetailsModal } from './components/FileDetailsModal';
import { Shield, ShieldAlert, CheckCircle2, Info, Download } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [scanResult, setScanResult] = useState<ForensicScanResult>(() => generateDemoForensicDataset());
  const [selectedFile, setSelectedFile] = useState<ReconstructedFile | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleLoadDemo = () => {
    const demo = generateDemoForensicDataset();
    setScanResult(demo);
    showToast('Loaded 24-hour hackathon forensic demo dataset');
  };

  const handleScanComplete = (result: ForensicScanResult) => {
    setScanResult(result);
    showToast(`Scan complete: ${result.reconstructedFiles.length} artifacts reconstructed`);
  };

  const handleDownloadZip = async () => {
    showToast('Packaging full forensic evidence & project files into .ZIP...');
    try {
      await downloadCompleteEvidenceZip(scanResult);
      showToast('Downloaded evidence ZIP (Phone & Desktop Verified)!');
    } catch {
      const link = document.createElement('a');
      link.href = '/recoveai_forensics_workbench.zip';
      link.download = 'recoveai_forensics_workbench.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Bar following Top Bar Contract */}
      <TopBar
        activeTab={activeTab}
        onNavigateTab={setActiveTab}
        onLoadDemo={handleLoadDemo}
        onDownloadZip={handleDownloadZip}
      />

      {/* Forensic Safe Environment Notice */}
      <div className="bg-slate-900/90 border-b border-slate-800 px-6 py-2 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2 text-slate-300">
          <Shield className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>
            <strong>ReCoveAI Forensic Sandbox</strong> · Certified read-only execution · Missing bytes are explicitly marked, never fabricated.
          </span>
        </div>
        <div className="hidden sm:flex items-center gap-3 text-slate-400 font-mono text-[11px]">
          <span>TSK / PhotoRec / OCR Bridges</span>
          <span className="text-slate-600">|</span>
          <span className="text-emerald-400">Target Unaltered</span>
        </div>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-cyan-500/50 text-slate-100 px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2.5 text-xs animate-in fade-in slide-in-from-bottom-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'dashboard' && (
          <DashboardView
            scanResult={scanResult}
            onSelectFile={setSelectedFile}
            onNavigateTab={setActiveTab}
            onLoadDemo={handleLoadDemo}
            onDownloadAllZip={handleDownloadZip}
          />
        )}

        {activeTab === 'upload' && (
          <UploadScanView
            onScanComplete={handleScanComplete}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'fragments' && (
          <FragmentExplorerView
            fragments={scanResult.fragments}
          />
        )}

        {activeTab === 'recovered' && (
          <RecoveredFilesView
            files={scanResult.reconstructedFiles}
            onSelectFile={setSelectedFile}
            onDownloadAllZip={handleDownloadZip}
          />
        )}

        {activeTab === 'graph' && (
          <EvidenceGraphView
            scanResult={scanResult}
            onSelectFile={setSelectedFile}
          />
        )}

        {activeTab === 'tools' && (
          <ForensicToolsView
            tools={scanResult.toolsInfo}
          />
        )}

        {activeTab === 'report' && (
          <AnalysisReportView
            scanResult={scanResult}
            onSelectFile={setSelectedFile}
          />
        )}
      </main>

      {/* File Inspector Modal */}
      {selectedFile && (
        <FileDetailsModal
          file={selectedFile}
          fragments={scanResult.fragments}
          onClose={() => setSelectedFile(null)}
          onNavigateToFile={id => {
            const target = scanResult.reconstructedFiles.find(f => f.id === id);
            if (target) setSelectedFile(target);
          }}
        />
      )}

      {/* Quiet Forensic Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 px-6 py-4 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span>ReCoveAI Digital Forensics & Data Recovery Workbench</span>
            <span aria-hidden="true">·</span>
            <span>24-Hour Cybersecurity & AI Hackathon Prototype</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] font-mono">
            <span>TSK · PhotoRec · Foremost · OCR · OpenCV</span>
            <span aria-hidden="true">·</span>
            <button
              onClick={handleDownloadZip}
              className="text-cyan-400 hover:text-cyan-300 underline underline-offset-2 flex items-center gap-1"
            >
              <Download className="w-3 h-3" />
              <span>recoveai_forensics_workbench.zip</span>
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
