from fastapi import FastAPI, UploadFile, File, Form, Query
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional
from .models import ForensicScanResponse
from .scanner import scan_raw_bytes
from .integrations.tool_detector import get_forensic_tools_status
from .integrations.sleuthkit import SleuthKitAnalyzer
from .integrations.photorec_carver import PhotoRecCarver
from .integrations.foremost_carver import ForemostCarver
from .integrations.ocr_engine import OcrEngine
from .integrations.cv_analyzer import CvAnalyzer
from .integrations.fragment_matcher import FragmentMatchingEngine
from .integrations.risk_engine import RiskIndicatorEngine

app = FastAPI(
    title="ReCoveAI Forensic Engine API",
    description="AI-Assisted Intelligent Data Recovery and Digital Evidence Reconstruction with SleuthKit, PhotoRec, Foremost, Tesseract & OpenCV extensions",
    version="1.2.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/health")
def health_check():
    return {
        "status": "online",
        "engine": "ReCoveAI-Forensic-v1.2",
        "mode": "read_only",
        "non_destructive": True
    }

@app.get("/api/tools/status")
def get_tools_status():
    """
    Checks availability of external forensic toolchains:
    - PhotoRec / TestDisk
    - The Sleuth Kit (fls, icat, tsk_recover)
    - Foremost / Scalpel
    - Tesseract OCR
    - OpenCV (cv2)
    Provides cross-platform installation instructions for Windows, Linux, and macOS.
    """
    return get_forensic_tools_status()

@app.get("/api/demo")
def get_demo_dataset():
    """Returns the prepared 24-hour hackathon digital forensics test scenario."""
    return {
        "scan_id": "REC-2026-HACKATHON-DEMO-01",
        "dataset_name": "forensic_evidence_image_sda2.dd",
        "dataset_size_bytes": 106496,
        "dataset_sha256": "9f83a214e59048a1d52033bc6547190822fa65e10034a7098231ff10984210a4",
        "sector_size": 512,
        "status": "ready"
    }

@app.post("/api/scan", response_model=ForensicScanResponse)
async def scan_disk_image(
    file: UploadFile = File(...),
    sector_size: int = Form(512)
):
    """
    Ingests user-provided sample disk image or file.
    Executes signature scanning, fragment carving, entropy analysis, and file reconstruction.
    """
    contents = await file.read()
    result = scan_raw_bytes(contents, file.filename or "unknown_evidence.dd", sector_size)
    return result

@app.post("/api/analyze/ocr")
async def analyze_ocr(
    file: Optional[UploadFile] = File(None),
    artifact_name: str = Form("IMG_0942_Badge_ID.jpg")
):
    """
    Runs Tesseract OCR (or built-in fallback) to extract names, badge IDs, and text
    from recovered images.
    """
    engine = OcrEngine()
    bytes_data = await file.read() if file else b""
    return engine.extract_text_from_image(bytes_data, artifact_name)

@app.post("/api/analyze/cv-quality")
async def analyze_cv_quality(
    file: Optional[UploadFile] = File(None),
    artifact_name: str = Form("IMG_0942_Badge_ID.jpg")
):
    """
    Runs OpenCV (or built-in fallback) to assess image quality, Laplacian blur,
    compression artifacts, and scanline corruption.
    """
    analyzer = CvAnalyzer()
    bytes_data = await file.read() if file else b""
    return analyzer.analyze_image_corruption(bytes_data, artifact_name)

@app.get("/api/graph/extended")
def get_extended_topology():
    """
    Returns 4-tier graph topology:
    Fragments ──► Reconstructed Files ──► Extracted Entities ──► Risk Indicators
    """
    return {
        "tiers": ["fragments", "reconstructed_files", "extracted_entities", "risk_indicators"],
        "summary": "4-tier evidentiary correlation pipeline"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend_fastapi.main:app", host="0.0.0.0", port=8000, reload=True)
