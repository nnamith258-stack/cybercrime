# ReCoveAI - Python FastAPI Forensic Engine

This directory provides the standalone Python FastAPI backend for **ReCoveAI** – AI-Assisted Intelligent Data Recovery and Digital Evidence Reconstruction.

## Architecture

```
Incoming Bitstream (.dd / .raw / .bin / custom)
         │
         ▼
[File Signature Scanner] ─── (JPEG, PNG, PDF, TXT, ZIP, MP4, DOCX)
         │
         ▼
[Fragment Carving Engine] ─── (Sector-level cluster splitting: 512B / 4KB)
         │
         ▼
[AI / Entropy Classifier] ─── (Shannon Entropy H, printable ASCII density, DCT heuristics)
         │
         ▼
[Fragment Continuity Matcher] (Offset adjacency, header-body-footer chains)
         │
         ▼
[File Reconstruction Engine]  (Assembles fragments, audits integrity %, flags gaps)
         │
         ▼
[SHA-256 Deduplication]     (Identifies clone artifacts in slack sectors)
         │
         ▼
[Forensic Case API]
```

## Running the Backend

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Start the FastAPI development server:
```bash
uvicorn backend_fastapi.main:app --host 0.0.0.0 --port 8000 --reload
```

3. Open Swagger / OpenAPI documentation at:
```
http://localhost:8000/docs
```
